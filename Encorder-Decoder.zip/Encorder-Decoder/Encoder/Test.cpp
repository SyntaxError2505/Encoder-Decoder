#include <iostream>
#include <string>
#include "EDEv1.h"

using namespace std;


int main()
{
    string input;
    while(0 == 0)
    {
        getline(cin, input);
        cout << Encode(input) << endl;
        cout << Decode(Encode(input)) << endl;
    }
}