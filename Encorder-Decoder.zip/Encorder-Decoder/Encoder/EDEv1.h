//The Name stands for Encoder-Decoder Version{Version}

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

//it's just the encoder. Easy to use.

string Encode(string Text)
{
    //Variables and Setup
    ifstream Code ("Code.txt");

    int i = 0;
    string Output = Text;
    string Zeile;
    int Length = Text.size();
    char Encoding[27][2];
    
    //Scanning the Code File
    i = 0;
    while(getline(Code, Zeile))
    {
        Encoding[i][0] = Zeile[0];
        Encoding[i][1] = Zeile[4];
        i += 1;
    }
    
    //for (int j = 0; j < 27; j += 1)
    //{
    //    cout << Encoding[j][0] << " " << Encoding[j][1] << endl;
    //}

    //Encoding
    i = 0;
    while(i != Length)
    {
        for (int j = 0; j < 27; j += 1)
        {
            if(tolower(Text[i]) == Encoding[j][0])
            {
                Output[i] = Encoding[j][1];
                break;
            }
        }
        i += 1;
    }
    //Output
    return Output;
}

//Decoder
string Decode(string Text)
{
    //Variables and Setup
    ifstream Code ("Code.txt");

    int i = 0;
    string Output = Text;
    string Zeile;
    int Length = Text.size();
    char Encoding[27][2];

    //Scanning the code file
    i = 0;
    while(getline(Code, Zeile))
    {
        Encoding[i][1] = Zeile[0];
        Encoding[i][0] = Zeile[4];
        i += 1;
    }
    
    //for (int j = 0; j < 27; j += 1)
    //{
    //    cout << Encoding[j][0] << " " << Encoding[j][1] << endl;
    //}

    //Decoding
    i = 0;
    while(i != Length)
    {
        for (int j = 0; j < 27; j += 1)
        {
            if(tolower(Text[i]) == Encoding[j][0])
            {
                Output[i] = Encoding[j][1];
                break;
            }
        }
        i += 1;
    }
    //Ok. Who doesn't understand this, should go learn english. RETURNING OUTPUT
    return Output;
}
